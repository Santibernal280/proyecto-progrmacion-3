// src/main.ts
import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Habilitar CORS
  app.enableCors();

  // Usar ValidationPipe global para DTOs
  app.useGlobalPipes(new ValidationPipe({
    whitelist: true,    // Elimina propiedades que no están en los DTOs
    forbidNonWhitelisted: true, // Lanza error si envían propiedades no permitidas
    transform: true,    // Transforma la data a los tipos correctos de los DTOs
  }));

  await app.listen(3001);
  console.log(`🚀 Server running on http://localhost:3001`);
}
bootstrap();
