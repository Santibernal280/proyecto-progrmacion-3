// src/app.module.ts
import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { PrismaModule } from './prisma/prisma.module';
import { UserModule } from './modules/user/user.module';
import { AuthModule } from './modules/auth/auth.module';
import { CanchaModule } from './modules/cancha/cancha.module';
import { ReservaModule } from './modules/reserva/reserva.module';
import { EquipoModule } from './modules/equipo/equipo.module';
import { ProfileModule } from './modules/profile/profile.module';

@Module({
  imports: [
    // Carga .env.local o .env.production según NODE_ENV
    ConfigModule.forRoot({
      isGlobal: true,
      envFilePath:
        process.env.NODE_ENV === 'production'
          ? '.env.production'
          : '.env.local',
    }),

    // Módulo global de Prisma (DB)
    PrismaModule,

    // Módulos de dominio
    UserModule,
    AuthModule,
    CanchaModule,
    ReservaModule,
    EquipoModule,
    ProfileModule,
  ],
})
export class AppModule {}
