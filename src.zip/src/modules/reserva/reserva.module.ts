import { Module } from '@nestjs/common';
import { ReservaController } from './controllers/reserva.controller';
import { ReservaService } from './services/reserva.service';

@Module({
  controllers: [ReservaController],
  providers: [ReservaService],
})
export class ReservaModule {}

