import { Controller } from '@nestjs/common';

@Controller('reservas')
export class ReservaController {}

