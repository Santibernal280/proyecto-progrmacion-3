export class UpdateReservaDto {
    fecha?: Date;
    horaInicio?: string;
    horaFin?: string;
  }
  
