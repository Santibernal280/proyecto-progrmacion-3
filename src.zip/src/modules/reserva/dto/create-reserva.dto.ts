export class CreateReservaDto {
    canchaId: number;
    equipoId: number;
    fecha: Date;
    horaInicio: string;
    horaFin: string;
  }
  
