export class CreateEquipoDto {
    nombre: string;
    descripcion: string;
  }
  
