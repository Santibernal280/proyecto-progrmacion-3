export class UpdateEquipoDto {
    nombre?: string;
    descripcion?: string;
  }
  
