import { Module } from '@nestjs/common';
import { EquipoController } from './controllers/equipo.controller';
import { EquipoService } from './services/equipo.service';

@Module({
  controllers: [EquipoController],
  providers: [EquipoService],
})
export class EquipoModule {}

