import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../../prisma/prisma.service';
import { CreateCanchaDto } from '../dto/create-cancha.dto';
import { UpdateCanchaDto } from '../dto/update-cancha.dto';

@Injectable()
export class CanchaService {
  constructor(private readonly prisma: PrismaService) {}

  create(createCanchaDto: CreateCanchaDto) {
    return this.prisma.cancha.create({
      data: createCanchaDto,
    });
  }

  findAll() {
    return this.prisma.cancha.findMany();
  }

  findOne(id: number) {
    return this.prisma.cancha.findUnique({
      where: { id },
    });
  }

  update(id: number, updateCanchaDto: UpdateCanchaDto) {
    return this.prisma.cancha.update({
      where: { id },
      data: updateCanchaDto,
    });
  }

  remove(id: number) {
    return this.prisma.cancha.delete({
      where: { id },
    });
  }
}
