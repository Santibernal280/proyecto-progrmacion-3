import { Module } from '@nestjs/common';
import { CanchaController } from './controllers/cancha.controller';
import { CanchaService } from './services/cancha.service';
import { PrismaService } from '../../prisma/prisma.service';


@Module({
  controllers: [CanchaController],
  providers: [CanchaService, PrismaService],
})
export class CanchaModule {}