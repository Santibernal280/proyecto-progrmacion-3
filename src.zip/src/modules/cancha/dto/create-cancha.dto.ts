import { IsNotEmpty, IsNumber, IsString } from 'class-validator';

export class CreateCanchaDto {
  @IsString()
  @IsNotEmpty()
  nombre: string;

  @IsString()
  @IsNotEmpty()
  ubicacion: string;

  @IsNumber()
  @IsNotEmpty()
  precioHora: number;  // 👈🏽 AGREGA ESTO
}
