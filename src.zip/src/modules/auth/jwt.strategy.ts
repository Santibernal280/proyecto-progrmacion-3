import { Injectable } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';  // Asegúrate de importar ConfigService
import { JwtPayload } from '../auth/jwt-payload.interface';  // Asegúrate de tener este archivo de interfaz

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private configService: ConfigService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,  // Esto controla si la expiración de JWT se ignora (si no, puede lanzarse un error si está expirado)
      secretOrKey: configService.get('JWT_SECRET'),  // Usamos JWT_SECRET del archivo .env
    });
  }

  // El método `validate` es utilizado para devolver el payload del JWT cuando la validación es exitosa
  async validate(payload: JwtPayload) {
    return { userId: payload.sub, email: payload.email };  // Puedes retornar más campos según tus necesidades
  }
}
