// src/modules/auth/jwt-payload.interface.ts

export interface JwtPayload {
    email: string;
    sub: number; // Puede ser cualquier tipo de ID, en este caso estamos usando un número
    role: string;
  }  