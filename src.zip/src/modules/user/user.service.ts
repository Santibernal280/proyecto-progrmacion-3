// src/modules/user/user.service.ts

import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';  // PrismaService para interactuar con la base de datos
import { CreateUserDto } from './dto/create-user.dto';  // DTO para crear un usuario

@Injectable()
export class UserService {
  constructor(private prisma: PrismaService) {}

  // Crear un usuario
  async create(createUserDto: CreateUserDto) {
    return this.prisma.user.create({
      data: createUserDto,
    });
  }

  // Obtener todos los usuarios
  async findAll() {
    return this.prisma.user.findMany();
  }

  // Buscar un usuario por correo
  async findOneByEmail(email: string) {
    return this.prisma.user.findUnique({
      where: {
        email,
      },
    });
  }

  // Obtener un usuario por id
  async findOne(id: number) {
    return this.prisma.user.findUnique({
      where: {
        id,
      },
    });
  }

  // Actualizar un usuario
  async update(id: number, updateUserDto: CreateUserDto) {
    return this.prisma.user.update({
      where: { id },
      data: updateUserDto,
    });
  }

  // Eliminar un usuario
  async remove(id: number) {
    return this.prisma.user.delete({
      where: { id },
    });
  }
}

