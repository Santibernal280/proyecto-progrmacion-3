export class UpdateUserDto {
    nombre?: string;
    correo?: string;
  }
  
