
import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { PrismaModule } from '../../prisma/prisma.module';  // Asegúrate de importar el PrismaModule

@Module({
  imports: [PrismaModule],  // PrismaModule para acceder a la base de datos
  controllers: [UserController],
  providers: [UserService],
})
export class UserModule {}
